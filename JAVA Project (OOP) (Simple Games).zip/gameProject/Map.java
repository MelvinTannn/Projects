package gameProject;

import java.util.ArrayList;

public class Map {

	protected ArrayList<String> field = new ArrayList<>();
	
	public ArrayList<String> getField(int x){
		field.clear();
		if(x == 1) {
			field.add(" ___________________________  _________");
			field.add("|   | |vvvvvvvvvvvv           vvvvvvvvv|");
			field.add("| ? | |vvvvvvvvvvvv           vvvvvvvvv|");
			field.add("|   | |vvvvvvvvvvvv           vvvvvvvvv|");
			field.add("|   | |vvvvvvvvvvvv                     ");
			field.add("|   | |vvvvvvvvvvvv           vvvvvvvvv|");
			field.add("|   |_|vvvvvvvvvvvvvvvvvvvvvvvvvvvv    |");
			field.add("|                  _________ vvvvvv    |");
			field.add("|vvvvvvvvvvvvvvvvv|_________|vvvvvv    |");
			field.add("|vvvvvvvvvvvvvvvvv          |vvvvvv    |");
			field.add("|________________________   |vvvvvv    |");
			field.add("|_________________|______|  |vvvvvv    |");
			field.add("|vvvvvvvvvvvvvvvvv| ?       |vvvvvv    |");
			field.add("|vvvvvvvvvvvvvvvvv|_________|vvvvvv    |");
			field.add("|vvvvvv    |    vvvvvvvvvvvvvvvvvvvvvvv|");
			field.add("|vvv       |    vvvvvvvvvvvvvvvvvvvvvvv|");
			field.add("|vvv       |                           |");
			field.add("|vvv    vvv|vvvvvvvvvv ________________|");
			field.add("|vvv    vvv|vvvvvvvvvv|________________|");
			field.add("|vvv    vvv|vvvvvvvvvvvvv            ? |");
			field.add("|____  ____|___________________________|");
		}else if(x == 2) {
			field.add(" ______________________________________");
			field.add("|vvvvvvvvvvvvvvvvvvv                 ? |");
			field.add("|vvvvvvvvvvvvvvvvvvv___________________|");
			field.add("                 vvvvvvvvvvvvvvvvvv    |");
			field.add("|vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv|vvv|");
			field.add("|______________________________ vvv|vvv|");
			field.add("|     |          x   x         |vvv|vvv|");
			field.add("|     | ?        |   |       ? |vvv|vvv|");
			field.add("|_____|__________|   |_________|vvv|vvv|");
			field.add("|  ?  |          |   |         |   |vvv|");
			field.add("|     |          |   |         |   |vvv|");
			field.add("|vvvvv|          |   |         |   |vvv|");
			field.add("|vvvvv|__________|   |_________|   |vvv|");
			field.add("|                x           ? |   |vvv|");
			field.add("|      __________     _________|vvv|vvv|");
			field.add("|vvvvv|          |   |         |vvv|vvv|");
			field.add("|vvvvv|          | ? |         |vvv|vvv|");
			field.add("|vvvvv|__________|___|_________|vvv|   |");
			field.add("|                vvvvvvvvvvvvvvvvvv|   |");
			field.add("|vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv| ? |");
			field.add("|__________________________________|___|");
		}else if(x == 3) {
			field.clear();
			field.add(" _____  _______________________________");
			field.add("|vvvvv  vvvvvvvvvvvvvvvvvv|            |");
			field.add("|vvvvv         vvvv       x        ?   |");
			field.add("|vvvvvvvvvvvvvvvvvvvvvv________________|");
			field.add("|vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv     |");
			field.add("|                        vvvvvvvvv     |");
			field.add("|___________________vvvvvvvvvvvvvv     |");
			field.add("|    vvvvvvvvvvvvvvvvvvvvvvvvvvvvv     |");
			field.add("|    vvvvvvvvvvvvvvvvvvvvvvvvvvvvv     |");
			field.add("|   |vvvvvvvvvvvvvvvvvvvvvvvvvvvvv     |");
			field.add("|   |vvvvvvvv                          |");
			field.add("|   |vvvvvvvv__________________________|");
			field.add("|   |vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv|");
			field.add("|   |vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv|");
			field.add("|   |                                  |");
			field.add("| ? |vvvvvvvvvvvvvvvvvvvvvvvvvvvvv     |");
			field.add("|___|________________________vvvvv     |");
			field.add("|vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv     |");
			field.add("|vvv        vvvvvvvvvvvv               |");
			field.add("|vvv  vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv|");
			field.add("|___  _________________________________|");
		}else if(x == 4) {
			field.add(" ___________________________________  _");
			field.add("|vvvvvvv|vvvvvvvvvvvvvvvvvvvvvvvvv|v  v|");
			field.add("|   |vvv|vvv|vvvvvvvvvvv|vvvvvvvvv|v  v|");
			field.add("| ? |vvvvvvv|vvvvvvvvvvv|vvvvvvvvv|v  v|");
			field.add("|___|_______|____    ___|____vvvvv|v  v|");
			field.add("|vvvvvvvvvvvvvvvv|  |    vvvv|vvvv|v  v|");
			field.add("|vvvvvvvvvvvvvvvv|  | ?  vvvv|v  v|v  v|");
			field.add("|vvv  vvv|vvvvvvv|  |    vvvv|v  v|vvvv|");
			field.add("|v vv   v|vvvvvvv|  |_____   |v  v|vvvv|");
			field.add("|vv   v v|vvvvvvv|vvvvvvvv|  |v  v|vvvv|");
			field.add("| vvvvvv |v  v __|_____vvv|  |v  v|vvvv|");
			field.add("|  vvvv  |v  v|vvvvvvvv|  |  |v  v|vvvv|");
			field.add("| v vv vv|v  v|vvvvvvvv|  |       |vvvv|");
			field.add("|   vvvvv|vvvv|vvvv|   |  |__     |vvvv|");
			field.add("|vvv  vvv|vvvv|vvvv|   |vvvvv|vvvv|vvvv|");
			field.add("|vvv  vvv|vvvv|vvvv|   |__vvv|vvvv|vvvv|");
			field.add("|vvv  vvv|         |vvvvvv|vv|vvvv|vvvv|");
			field.add("|vvv  vvv|    _____|__vvvv|vv|vvvv|vvvv|");
			field.add("|vv    vv|vvvvvvv     |vvv|vv|vvvv|vvvv|");
			field.add("|vv    vv|vvvvvvv   ? |vvvvvv|vvvvvvvvv|");
			field.add("|___  ___|____________|______|_________|");
		}else if(x == 5) {
			field.add(" __  __________________________________");
			field.add("|vv  vvvvvvvvvvvvvvvvvvvvvvvv          |");
			field.add("|vv  vvvvvvvvvvvvvvvvvvvvvvvv       ?  |");
			field.add("|vvvvv_________________________________|");
			field.add("|vvvvvvvvvvvvv       vvvvvvvvvvvvvvvvvv|");
			field.add("|vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv|");
			field.add("|vvvvvvvvvvvvv       vvvvvvvvvv|vvvvvvv|");
			field.add("|______________________|vvvvvvv|       |");
			field.add("|vvvvvvvvvvvvvvvvvvvvvvvv      |       |");
			field.add("|vvvvvvvvvvvvvvvvvvvvvvvv      |   ?   |");
			field.add("|vvvvvv________________________|_______|");
			field.add("|vvvvv|vvvvvvvvvvvvvvvvvvvvvvvv      ? |");
			field.add("|  vvv|vvvvvvvv________________________|");
			field.add("|  vvv|   vvvv|vvvvvvvvvvvvvvvvvvvvvvvv|");
			field.add("|  vvv|   vvvv|vvvvvvvvvvvvvvvvvvvvvvvv|");
			field.add("|  vvv|   vvvv|vvvvvvv|vvvvvv|vvvvvvvvv|");
			field.add("|vvvvv|vvvvvvvvvvvvvvv|vv  vv|vvvvv  vv|");
			field.add("|vvvvvvvvvvvvvvvvvvvvv|vv  vv|vvvvv  vv|");
			field.add("|_____________________|vv  vv|vvvvv  vv|");
			field.add("| ?         vvvvvvvvvvvvvvvvv|vvvvv  vv|");
			field.add("|____________________________|_____  __|");
		}else if(x == 6) {
			field.add(" ______________________________________");
			field.add("|     |       |          |       |     |");
			field.add("|  ?  |_______|          |_______|  ?  |");
			field.add("|     |                          |     |");
			field.add("|     |            x             |     |");
			field.add("|     |                          |     |");
			field.add("|     |                          |     |");
			field.add("|vvvvv|                          |vvvvv|");
			field.add("|vvvvv|                          |vvvvv|");
			field.add("|vvvvv|___________   ____________|vvvvv|");
			field.add("|vvvvv|vvvvvvvvvvv   vvvvvvvvvvvv|vvvvv|");
			field.add("|vvvvv|vvvvvvvvvvv   vvvvvvvvvvvv|vvvvv|");
			field.add("|vvvvv|vvvvvvvvvvvvvvvvvvvvvvvvvv|vvvvv|");
			field.add("|vvvvv|vvvvvvvvvvvvvvvvvvvvvvvvvv|vvvvv|");
			field.add("|vvvvv|vvvvvvvvvvvvvvvvvvvvvvvvvv|vvvvv|");
			field.add("|vvvvv|vvvvvvvvvvv   vvvvvvvvvvvv|vvvvv|");
			field.add("|vvvvv|vvvvvvvvvvv   vvvvvvvvvvvv|vvvvv|");
			field.add("|vvvvv|____________  ____________|vvvvv|");
			field.add("|vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv|");
			field.add("|vvvvvvvvvvvvvvvvvv  vvvvvvvvvvvvvvvvvv|");
			field.add("|__________________  __________________|");
		}
		return new ArrayList<String>(field);
	}

}
