package gameProject;

public class Ogre extends Swordman{

	public Ogre() {
		super("Ogre", 70, 30, 25, 5,40);
	}

	public void image() {
		System.out.println("       _____   _____            ");
		System.out.println("      |  \\/ | |  \\/ |  ___    ");
		System.out.println("      | |oo|| | |oo||<| | |>    ");
		System.out.println("      |  __ | |  __ |<| | |>    ");
		System.out.println("      |_____|_|_____|<| | |>    ");
		System.out.println("     /              \\__| |     ");
		System.out.println("    / /               _| |      ");
		System.out.println("   / /                || |      ");
		System.out.println("  (-)|                |(_)      ");
		System.out.println("     \\_______________/         ");
		System.out.println("      (_)          (_)          ");
	}
}
