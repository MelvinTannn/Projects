package gameProject;

public class Musketeer extends Bowman{

	public Musketeer() {
		super("Musketeer", 20, 20, 8, 14, 50);
	}

}
