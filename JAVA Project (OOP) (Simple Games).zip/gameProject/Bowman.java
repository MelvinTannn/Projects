package gameProject;

import java.util.*;

public class Bowman extends Profile implements Special{
	private int range;
	
	Random rand = new Random();
	
	public Bowman(String name, int health, int attack, int defend, int speed, int range) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.health = health;
		this.attack = attack;
		this.defend = defend;
		this.speed = speed;
		this.range = range;
		
	}
	public int getRange() {
		return range;
	}
	public void setRange(int range) {
		this.range = range;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public int getDefend() {
		return defend;
	}

	public void setDefend(int defend) {
		this.defend = defend;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public int getSpecial(){
		return range;
	}
	
	public void setSpecial(int range){
		this.range = range;
	}
	
	public int hasil(){
		int aa = rand.nextInt(range);
		return aa;
	}
	
	public int luck(){
		int bb = hasil();
		return bb;
	}
	
	public void image(){
		
	}
	
	
	

}
