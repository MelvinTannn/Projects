package gameProject;

public class Dwarf extends Bowman{

	public Dwarf() {
		super("Dwarf", 35, 40, 10, 15, 25);
	}

	public void image() {
		System.out.println("       ___________    __    __     ");
		System.out.println("      /           \\  | |__/  |    ");
		System.out.println("     ( _____  _____) |       |     ");
		System.out.println("      | |_| \\_/ |_|| | |\\____|   ");
		System.out.println("       \\\\_______//   | |         ");
		System.out.println("      / \\\\     //\\   | |        ");
		System.out.println("     /   \\\\___//  \\__| |        ");
		System.out.println("    / /            __| |           ");
		System.out.println("   / /             | | |           ");
		System.out.println("  (-)\\_____________/ (_)          ");
		System.out.println("      (_)       (_)                ");
	}
}
