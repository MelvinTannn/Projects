package gameProject;

public class Cockatrice extends Swordman{

	public Cockatrice() {
		super("Cockatrice", 25, 15, 5, 20, 15);
	}
	
	public void image() {
		System.out.println("       /\\");
		System.out.println("      /  \\");
		System.out.println("     /    \\");
		System.out.println("    | |  | |");
		System.out.println("    |  /\\  | ");
		System.out.println("  /\\\\  \\/  //\\");
		System.out.println(" /  \\\\    //  \\");
		System.out.println(" \\  / \\__/ \\  /");
		System.out.println("  \\/        \\/");
		System.out.println("   \\________/ ");
		System.out.println("    /|\\  /|\\");
	}

}
