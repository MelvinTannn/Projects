package gameProject;

public class LivingWood extends Mage{

	public LivingWood() {
		super("Living Wood", 30, 10, 20, 3, 10);
	}
	
	public void image(){
		System.out.println(" ___    _  ______");
		System.out.println(" \\  \\  / | \\    /");
		System.out.println("  \\  \\/  /__\\  /");
		System.out.println("   \\          /");
		System.out.println("   |   _   _  |");
		System.out.println("   |  |_| |_| |");
		System.out.println("   |   ____   |");
		System.out.println("   |  |\\/\\/|  |");
		System.out.println("   |  \"\"\"\"\"\"  |");
		System.out.println("  / /|  |  /\\ \\");
		System.out.println(" /_/ |__|\\/  \\_\\");
	}

}
