package gameProject;

public interface Special {

	int hasil();
}
