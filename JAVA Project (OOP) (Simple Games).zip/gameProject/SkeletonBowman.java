package gameProject;

public class SkeletonBowman extends Bowman{

	public SkeletonBowman() {
		super("Skeleton Bowman", 15, 20, 15, 13, 35);
	}

	public void image() {
		System.out.println("      _______");
		System.out.println("     / _   _ \\");
		System.out.println("  . / |_| |_| \\");
		System.out.println(" /_\\\\    o    /");
		System.out.println("  |  |_|_|_|_|");
		System.out.println(" (_)_____|_____(_)\\");
		System.out.println("  | _____|_____  | \\");
		System.out.println("  | _____|_____  |  )");
		System.out.println(" /|\\    _|_      | /");
		System.out.println("       |   |     |/");
		System.out.println("      (_) (_)");
	}
}
