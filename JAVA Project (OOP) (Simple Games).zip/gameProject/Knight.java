package gameProject;

public class Knight extends Swordman {

	public Knight() {
		super("Knight",50, 40, 30, 30, 50);
	}

	public void image() {
		System.out.println("       ________            ");
		System.out.println("      /  ____  \\ /-\\     ");
		System.out.println("     (  (    )  )| |       ");
		System.out.println("     |   |__|   || |       ");
		System.out.println("     \\__________/| |      ");
		System.out.println("  ___/___    ___\\|_|____  ");
		System.out.println(" /       \\   \\___|_|___/ ");
		System.out.println(" |  <->  |       |_|       ");
		System.out.println(" \\_______/       (_)      ");
		System.out.println("     \\__________/         ");
		System.out.println("     (_)      (_)          ");
	}
}
