package gameProject;

public class GiantBush extends Swordman{

	public GiantBush() {
		super("Giant Bush", 15, 5, 10, 10, 10);
	}
	
	public void image(){
		System.out.println("       _________");
		System.out.println("     _(         )");
		System.out.println("    (            )");
		System.out.println("   (    __    __  )_");
		System.out.println("  (    |  |  |  |   )");
		System.out.println(" (     |  |  |  |   .'");
		System.out.println("  (    |__|  |__|   \\");
		System.out.println(" /                   )");
		System.out.println("(_                    )");
		System.out.println("  (                 _)");
		System.out.println("   (________________)");
	}

}
