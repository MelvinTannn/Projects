package gameProject;

public class Monk extends Mage {

	public Monk() {
		super("Monk", 25, 5, 10, 12, 40);
	}

}
