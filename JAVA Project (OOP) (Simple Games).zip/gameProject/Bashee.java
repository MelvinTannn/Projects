package gameProject;

public class Bashee extends Mage{

	public Bashee() {
		super("Bashee", 10, 7, 4, 20, 40);
	}
	
	public void image() {
		System.out.println("a");
	}

}
