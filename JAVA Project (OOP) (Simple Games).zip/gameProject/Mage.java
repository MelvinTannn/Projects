package gameProject;

import java.util.*;

public class Mage extends Profile implements Special{

private int magic;

Random rand = new Random();
	
	public Mage(String name, int health, int attack, int defend, int speed, int magic) {
		// TODO Auto-generated constructor stub
		super();
		this.name = name;
		this.health = health;
		this.attack = attack;
		this.defend = defend;
		this.speed = speed;
		this.magic=magic;
	}

	public int getMagic() {
		return magic;
	}

	public void setMagic(int magic) {
		this.magic = magic;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public int getDefend() {
		return defend;
	}

	public void setDefend(int defend) {
		this.defend = defend;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSpecial(){
		return magic;
	}
	
	public void setSpecial(int magic){
		this.magic = magic;
	}
	
	public int hasil(){
		int aa = rand.nextInt(magic);
		return aa;
	}
	
	public int luck(){
		int bb = hasil();
		return bb;
	}
	
	public void image() {
		
	}
}
