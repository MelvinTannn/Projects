package gameProject;

public class Warlock extends Mage{

	public Warlock() {
		super("Warlock", 20, 12, 3, 25, 100);
	}

	public void image() {
		System.out.println("a");
	}
}
