package gameProject;

public class RabidDog extends Swordman{

	public RabidDog() {
		super("Rabid Dog", 25, 5, 5, 30, 15);
	}

	public void image() {
		System.out.println("     .       .");
		System.out.println("     /\\      /\\");
		System.out.println("    (  )____(  )");
		System.out.println("    (   _   _  )");
		System.out.println("    /  |_| |_| \\");
		System.out.println("    \\   ____   /");
		System.out.println("    _\\__\\/\\/__/_");
		System.out.println("   (_/  ____  \\_)   ");
		System.out.println("    /  /    \\  \\    ");
		System.out.println("    \\__\\____/__/    ");
		System.out.println("     (__)  (__)    ");
	}
}
