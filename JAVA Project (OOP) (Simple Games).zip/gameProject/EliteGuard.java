package gameProject;

public class EliteGuard extends Swordman {

	public EliteGuard() {
		super("Elite Guard", 45, 35, 25, 20, 50);
	}

	public void image() {
		System.out.println("       /\\____/\\  /-\\ __ ");
		System.out.println("      /  ____  \\ | |/  |  ");
		System.out.println("     (  /    \\  )|     |  ");
		System.out.println("     |  |_/\\_|  || |\\__| ");
		System.out.println("     \\__________/| |      ");
		System.out.println("  ___/___       \\| |      ");
		System.out.println(" /       \\       | |      ");
		System.out.println(" |  >-<  |       | |       ");
		System.out.println(" \\_______/       (_)      ");
		System.out.println("     \\__________/         ");
		System.out.println("     (_)      (_)          ");
	}
}
