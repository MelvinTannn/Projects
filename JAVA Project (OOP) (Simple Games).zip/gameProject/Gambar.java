package gameProject;

public class Gambar implements Runnable{

	String tanda;
	public Gambar(String tanda) {
		// TODO Auto-generated constructor stub
		super();
		this.tanda = tanda;
	}
	
	public void run(){
		if(tanda.equals("BowMan")){
		try {
			System.out.println("                                                   _______");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
		}
		try {
			System.out.println("                                            ______/       \\______");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
		}
		try {
			System.out.println("                                           /______________ ______\\");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
		}
		try {
			System.out.println("                                                /          \\/\\/\\/ ");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
		}
		try {
			System.out.println("                                                \\         _/_/_/_ ");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
		}
		try {
			System.out.println("                                                _\\_______/      / ");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
		}
		try {
			System.out.println("                                             ___\\       /      /_ ");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
		}
		try {
			System.out.println("                                            /    \\     /      /  \\");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
		}
		try {
			System.out.println("                                           /      \\   /      /    \\");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
		}
		try {
			System.out.println("                                          /        \\ /      /      \\");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
		}
		try {
			System.out.println("                                         /          /______/        \\");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
		}
		try {
			System.out.println("                                        /                            \\");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interupted!!!");
			}
		} else if(tanda.equals("SwordMan")){
			try {
				System.out.println("                                                  ____/\\____     __");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                                 /          \\   / /  ");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                                 \\         _/__/ /___");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                                  \\       /_________/ ");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                                 _/________\\/   /    ");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                           ______\\         /   /______");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                          |______|        /   /|______|");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                            /    \\       /   / /     \\  ");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                           /      \\     /   / /       \\  ");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                          /        \\___/   /_/         \\");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                         /            /   /             \\");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                        /             \\__/               \\");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
		} else {
			try {
				System.out.println("                                                 ________        ____");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                                /        \\      /    \\");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                               /          \\    (      )");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                              /            \\    \\____/ ");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                              \\/_\\______/_\\/    /   /");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                             ___\\        /___  /   /");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                            /    \\      /    \\/   /  ");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                           /      \\____/      \\  /          ");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                          /                    \\/");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                         /                      \\");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
			try {
				System.out.println("                                        /                        \\");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("Interupted");
			}
		}
	}


}
