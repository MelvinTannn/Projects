package gameProject;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


public class Main {

	static Random rand = new Random();
	static Scanner scan = new Scanner(System.in);
	static ArrayList<Profile> monsterList = new ArrayList<>();
	static ArrayList<Profile> playerList = new ArrayList<>();
	static ArrayList<String> map = new ArrayList<>();
	static Map m = new Map();
	static int exp = 0;
	static int mapStage = 1;
	static int indexPlayer;
	static int indexMonster;
	static int playerX;
	static int playerY;
	static String temp = "";
	static int temp1 = 0;
	static int temp2 = 0;
	static int attack1 = 0;
	static int defend1 = 0;
	static int special1 = 0;
	static int speed1 = 0;
	static int monscount = 3;
	static Thread bow = new Thread(new Gambar("BowMan"));
	static Thread sword = new Thread(new Gambar("SwordMan"));
	static Thread magic = new Thread(new Gambar("Mage"));
	
	
	
	static void Rules(){
		System.out.println("Hello and welcome to Short Adventure game");
		System.out.println("Here are some rules and guide to help you to play and explore the beautifull world of Kultz");
		System.out.println("1. First of all you can play only a character.");
		System.out.println("2. Each characters have it own class (SwordsMan, Bowman, Mage)");
		System.out.println("3. Each class have their unique ability (Swordman = Physical, Bowman = Range, Mage = magic)");
		System.out.println("4. The purpose of the unique ability is to use the special attack(which will be explained later)");
		System.out.println("5. The gameplay of this game is the player can move throught the map using the action move and the direction is using the (W,A,S,D key in the keyboard)");
		System.out.println("6. The map contain 3 elements :");
		System.out.println("Plain tile -> no effect when the player step into the tile");
		System.out.println("Grass tile(v) -> when the player step into the tile the system will roll randomly to tell are the player facing with monster or not");
		System.out.println("Wall tile(| & _) -> player can't step into the tile");
		System.out.println("7. When player encounter the monster in the grass tile, player will move into the battle phase");
		System.out.println("8. In the battle phase there are 3 action that player can make :");
		System.out.println("The attack action -> in this action the player will attack the monster equals to the attack number that player have in their stats");
		System.out.println("The special attack action -> in this action the player will attack the monster using the 50% number from the attack and random number range from the special attack number");
		System.out.println("The show stat action -> in this action the system will show the player their stats and their opponent stats");
		System.out.println("9. The speed number in each character stats will determine who will attack first in the battle phase (The bigger the faster)");
		System.out.println("10. When the player win the battle, he/she will level up and their stats fully recovered and increased");
		System.out.println("11. When the player lose the battle or died, he/she will be removed from the battle and start a new game");
		System.out.println("So that's all about the rules and guide in this game, happy fighting great adventurer");
		System.out.println("Press enter to continue...");
		scan.nextLine();
	}
	static void phaseBattle(int inde){
		System.out.println("You have meet "+monsterList.get(inde).getName());
		monsterList.get(inde).image();
		System.out.println("Press enter to proceed to battle");
		scan.nextLine();
		do {
			Battle(monsterList, inde);
		} while (playerList.get(0).getHealth()>0 && monsterList.get(inde).getHealth()>0);
		playerList.get(0).setHealth(temp1);
		monsterList.get(inde).setHealth(temp2);
	}
	
	static void Battle(ArrayList<Profile>ListM, int idx){
		int chance = 0;
		int aksi=0;
		int hp1 = playerList.get(0).getHealth();
		temp1 = hp1;
		int hp2 = ListM.get(idx).getHealth();
		temp2 = hp2;
		System.out.println("Your Stat");
		System.out.printf("%-15s : %s\n","Name", playerList.get(0).getName());
		if(check(playerList.get(indexPlayer)) == 1){
			System.out.printf("%-15s : %s\n","Class", "SwordsMan");
		} else if (check(playerList.get(indexPlayer)) == 2){
			System.out.printf("%-15s : %s\n","Class", "BowMan");
		} else {
			System.out.printf("%-15s : %s\n","Class", "Mage");
		}
		System.out.printf("%-15s : %d\n","Health", playerList.get(0).getHealth());
		System.out.printf("%-15s : %d\n","Attack", playerList.get(0).getAttack());
		System.out.printf("%-15s : %d\n","Defend", playerList.get(0).getDefend());
		System.out.printf("%-15s : %d\n","Speed", playerList.get(0).getSpeed());
		if(check(playerList.get(indexPlayer)) == 1){
			System.out.printf("%-15s : %d\n","Physical", playerList.get(0).getSpecial());
		} else if(check(playerList.get(indexPlayer))== 2){
			System.out.printf("%-15s : %d\n","Range", playerList.get(0).getSpecial());
		} else {
			System.out.printf("%-15s : %d\n","Magic", playerList.get(0).getSpecial());
		}
		System.out.println("Monster Stat");
		System.out.printf("%-15s : %s\n","Name", ListM.get(idx).getName());
		if(check(ListM.get(idx)) == 1){
			System.out.printf("%-15s : %s\n","Class", "SwordsMan");
		} else if(check(ListM.get(idx)) == 2){
			System.out.printf("%-15s : %s\n","Class", "BowMan");
		} else {
			System.out.printf("%-15s : %s\n","Class", "Mage");
		}
		System.out.printf("%-15s : %d\n","Health", ListM.get(idx).getHealth());
		System.out.printf("%-15s : %d\n","Attack", ListM.get(idx).getAttack());
		System.out.printf("%-15s : %d\n","Defend", ListM.get(idx).getDefend());
		System.out.printf("%-15s : %d\n","Speed", ListM.get(idx).getSpeed());
		if(check(ListM.get(idx)) == 1){
			System.out.printf("%-15s : %d\n","Physical", ListM.get(idx).getSpecial());
		} else if(check(ListM.get(idx)) == 2){
			System.out.printf("%-15s : %d\n","Range", ListM.get(idx).getSpecial());
		} else {
			System.out.printf("%-15s : %d\n","Magic", ListM.get(idx).getSpecial());
		}
		System.out.println("1. Attack");
		System.out.println("2. Special Attack");
		do {
			try {
				System.out.print("Choose >> ");
				aksi = scan.nextInt();
				scan.nextLine();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Must input with numbers!");
				scan.nextLine();
			} 
		} while (aksi!=1 && aksi!=2);
		switch(aksi){
		case 1:
			if(playerList.get(0).getSpeed()>=ListM.get(idx).getSpeed()){
				hp2 -= playerList.get(0).getAttack();
				if(hp2>0){
					chance = rand.nextInt(2);
					if(chance == 0){
						hp1 -= ListM.get(idx).getAttack();
					} else {
						hp1 -= ListM.get(idx).getSpecial();
					}
					System.out.println("You attacked first!!! & dealt "+playerList.get(0).getAttack()+" damage.");
					System.out.println("Press enter to continue...");
					scan.nextLine();
				} else {
					System.out.println(ListM.get(idx).getName()+" has been defeated!");
					System.out.println("Press enter to continue...");
					scan.nextLine();
				}
				playerList.get(0).setHealth(hp1);
				ListM.get(idx).setHealth(hp2);
			} else {
				chance = rand.nextInt(2);
				if(chance == 0){
					hp1 -= ListM.get(idx).getAttack();
				} else {
					hp1 -= ListM.get(idx).getSpecial();
				}
				
				if(hp1>0){
					hp2 -= playerList.get(0).getAttack();
					System.out.println(ListM.get(idx).getName()+" attaked first!!!");
					System.out.println("You dealt "+playerList.get(0).getAttack()+" damage.");
					System.out.println("Press enter to continue...");
					scan.nextLine();
				} else {
					System.out.println("You Lost the battle!");
					System.out.println("Press Enter to continue...");
					scan.nextLine();
				}
				playerList.get(0).setHealth(hp1);
				ListM.get(idx).setHealth(hp2);
			}
			break;
			
		case 2:
			int base = playerList.get(0).getAttack()/2;
			int bonus = playerList.get(0).luck(); 
			int total = base+bonus;
			if(playerList.get(0).getSpeed()>=ListM.get(idx).getSpeed()){
				hp2 -= total;
				if(hp2>0){
					chance = rand.nextInt(2);
					if(chance == 0){
						hp1 -= ListM.get(idx).getAttack();
					} else {
						hp1 -= ListM.get(idx).getSpecial();
					}
					System.out.println("You attacked first!!! & dealt "+total+" damage.");
					System.out.println("Press enter to continue...");
					scan.nextLine();
				} else {
					System.out.println(ListM.get(idx).getName()+" has been defeated!");
					System.out.println("Press enter to continue...");
					scan.nextLine();
				}
			} else {
				chance = rand.nextInt(2);
				if(chance == 0){
					hp1 -= ListM.get(idx).getAttack();
				} else {
					hp1 -= ListM.get(idx).getSpecial();
				}
				
				if(hp1>0){
					hp2 -= total;
					System.out.println(ListM.get(idx).getName()+" attaked first!!!");
					System.out.println("You dealt "+total+" damage.");
					System.out.println("Press enter to continue...");
					scan.nextLine();
				} else {
					System.out.println("You Lost the battle!");
					System.out.println("Press Enter to continue...");
					scan.nextLine();
				}
				playerList.get(0).setHealth(hp1);
				ListM.get(idx).setHealth(hp2);
			}
			break;
		}
	}
	
	static void addMonster(){
		//Tier 1
		Profile Mons = new GiantBush();
		monsterList.add(Mons);
		Profile Mons2 = new UndeadWarrior();
		monsterList.add(Mons2);
		Profile Mons3 = new Ghoul();
		monsterList.add(Mons3);
		Profile Mons4 = new LivingWood();
		monsterList.add(Mons4);
		
		//Tier 2
		Profile Mons5 = new RabidDog();
		monsterList.add(Mons5);
		Profile Mons6 = new Cockatrice();
		monsterList.add(Mons6);
		Profile Mons7 = new Bashee();
		monsterList.add(Mons7);
		Profile Mons8 = new Monk();
		monsterList.add(Mons8);
		
		//Tier 3
		Profile Mons9 = new SkeletonBowman();
		monsterList.add(Mons9);
		Profile Mons10 = new Mimic();
		monsterList.add(Mons10);
		Profile Mons11 = new Musketeer();
		monsterList.add(Mons11);
		Profile Mons12 = new Ranger();
		monsterList.add(Mons12);
		
		//Tier 4
		Profile Mons13 = new AxeThrower();
		monsterList.add(Mons13);
		Profile Mons14 = new Dwarf();
		monsterList.add(Mons14);
		Profile Mons15 = new Wizard();
		monsterList.add(Mons15);
		
		//Tier 5
		Profile Mons16 = new Knight();
		monsterList.add(Mons16);
		Profile Mons17 = new Warlock();
		monsterList.add(Mons17);
		Profile Mons18 = new Ogre();
		monsterList.add(Mons18);
		Profile Mons19 = new EliteGuard();
		monsterList.add(Mons19);
	}
	
	static void cls() {
		for(int i = 0; i < 30; i++) {
			System.out.println("");
		}
	}
	
	static void printMap() {
		int size = map.size();
		for(int i = 0; i < size; i++) {
			for(int j = 0; j < map.get(i).length(); j++) {
				System.out.print(map.get(i).charAt(j));
			}
			if(i == 1) {
				System.out.print("          1. Move");
			}else if(i == 2) {
				System.out.print("          2. Check Status");
			}else if(i == 3) {
				System.out.print("          3. Open Inventory");
			}else if(i == 4) {
				System.out.print("          4. Exit game");
			}else if(i == 6) {
				System.out.print("          >> if you pressed 1, press :");
			}else if(i == 7) {
				System.out.print("          W to move up");
			}else if(i == 8) {
				System.out.print("          S to move down");
			}else if(i == 9) {
				System.out.print("          A to move left");
			}else if(i == 10) {
				System.out.print("          D to move right");
			}
			System.out.println("");
		}
	}
	
	static int check(Profile p){
		if(p instanceof Swordman) {
			return 1;
		}else if(p instanceof Bowman) {
			return 2;
		}else {
			return 3;
		}
	}
	
	static void showStat(){
		System.out.println("Character Info");
		System.out.printf("%-15s : %s\n","Name", playerList.get(0).getName());
		
		if(check(playerList.get(indexPlayer)) == 1) {
			System.out.printf("%-15s : %s\n","Class","Swordsman");
		}else if(check(playerList.get(indexPlayer)) == 2) {
			System.out.printf("%-15s : %s\n","Class","Bowman");
		}else {
			System.out.printf("%-15s : %s\n","Class","Mage");
		}
		
		System.out.printf("%-15s : %d\n","Health", playerList.get(0).getHealth());
		System.out.printf("%-15s : %d\n","Attack", playerList.get(0).getAttack());
		System.out.printf("%-15s : %d\n","Defend", playerList.get(0).getDefend());
		System.out.printf("%-15s : %d\n","Speed", playerList.get(0).getSpeed());
		
		if(check(playerList.get(indexPlayer)) == 1) {
			System.out.printf("%-15s : %d\n","Physical", playerList.get(0).getSpecial());
			sword.run();
		}else if(check(playerList.get(indexPlayer)) == 2) {
			System.out.printf("%-15s : %d\n","Range", playerList.get(0).getSpecial());
			bow.run();
		}else {
			System.out.printf("%-15s : %d\n","Magic", playerList.get(0).getSpecial());
			magic.run();
		}
		
		System.out.println("Press Enter to continue...");
		scan.nextLine();
		
	}

	static void Menu(){
		System.out.printf("  .-')    ('-. .-.             _  .-')   .-') _            ('-.     _ .-') _        (`-.      ('-.       .-') _  .-') _               _  .-')     ('-.   \r\n");
		System.out.printf(" ( OO ). ( OO )  /            ( \\( -O ) (  OO) )          ( OO ).-.( (  OO) )     _(OO  )_  _(  OO)     ( OO ) )(  OO) )             ( \\( -O )  _(  OO)  \r\n");
		System.out.printf("(_)---\\_),--. ,--. .-'),-----. ,------. /     '._         / . --. / \\     .'_ ,--(_/   ,. \\(,------.,--./ ,--,' /     '._ ,--. ,--.   ,------. (,------. \r\n");
		System.out.printf("/    _ | |  | |  |( OO'  .-.  '|   /`. '|'--...__)        | \\-.  \\  ,`'--..._)\\   \\   /(__/ |  .---'|   \\ |  |\\ |'--...__)|  | |  |   |   /`. ' |  .---' \r\n");
		System.out.printf("\\  :` `. |   .|  |/   |  | |  ||  /  | |'--.  .--'      .-'-'  |  | |  |  \\  ' \\   \\ /   /  |  |    |    \\|  | )'--.  .--'|  | | .-') |  /  | | |  |     \r\n");
		System.out.printf(" '..`''.)|       |\\_) |  |\\|  ||  |_.' |   |  |          \\| |_.'  | |  |   ' |  \\   '   /, (|  '--. |  .     |/    |  |   |  |_|( OO )|  |_.' |(|  '--.  \r\n");
		System.out.printf(".-._)   \\|  .-.  |  \\ |  | |  ||  .  '.'   |  |           |  .-.  | |  |   / :   \\     /__) |  .--' |  |\\    |     |  |   |  | | `-' /|  .  '.' |  .--'  \r\n");
		System.out.printf("\\       /|  | |  |   `'  '-'  '|  |\\  \\    |  |           |  | |  | |  '--'  /    \\   /     |  `---.|  | \\   |     |  |  ('  '-'(_.-' |  |\\  \\  |  `---. \r\n");
		System.out.printf(" `-----' `--' `--'     `-----' `--' '--'   `--'           `--' `--' `-------'      `-'      `------'`--'  `--'     `--'    `-----'    `--' '--' `------' ");
		System.out.print("");
		System.out.println();
		System.out.println("1. New Game");
		System.out.println("2. Load Game");
		System.out.println("3. Rules & How To Play");
		System.out.println("4. Exit");
		System.out.print("Choose >> ");
	}

	static void locate(int x, int y) {
		//set wall
		if(map.get(playerY + y).charAt(playerX + x) == '|' || map.get(playerY + y).charAt(playerX + x) == '_') {
			System.out.println("You hit the wall!!!");
			System.out.println("Press enter to continue...");
			scan.nextLine();
			return;
		} else if (map.get(playerY + y).charAt(playerX + x) == 'v'){
			int chance = rand.nextInt(5);
			if(chance == 2){
				System.out.println("You meet a monster");
				System.out.println("Press enter to continue...");
				scan.nextLine();
				int select = rand.nextInt(monscount);
				phaseBattle(select);
				if(playerList.get(0).getHealth()<=0){
					System.out.println("You lost the battle");
					System.out.println("Press enter to back to main menu");
					scan.nextLine();
				} else if (monsterList.get(select).getHealth()<=0){
					System.out.println("You won the battle");
					System.out.println("Your character have leveled up");
					System.out.println("Press enter to back to map");
					scan.nextLine();
					temp1+=4;
					playerList.get(0).setHealth(temp1);
					monsterList.get(select).setHealth(temp2);
					attack1+=2;
					playerList.get(0).setAttack(attack1);
					defend1+=3;
					playerList.get(0).setDefend(defend1);
					speed1+=4;
					playerList.get(0).setSpeed(speed1);
					special1+=3;
					playerList.get(0).setSpecial(special1);
				}
			}
		}
		
		//check move location
		if(playerX + x == 39 && playerY + y == 4 && mapStage == 1) {//map 1 to map 2
			temp ="";
			mapStage++;
			map = m.getField(mapStage);
			monscount+=4;
			playerX = 1;
			playerY = 3;
			locate(0,0);
			return;
		}
		else if(playerX + x == 0 && playerY + y == 3 && mapStage == 2) {//map 2 to map 1
			temp ="";
			mapStage--;
			map = m.getField(mapStage);
			monscount-=4;
			playerX = 38;
			playerY = 4;
			locate(0,0);
			return;
		}
		else if(playerX + x == 28 && playerY + y == 0 && mapStage == 1) {//map 1 to map 3
			temp ="";
			mapStage += 2;
			map = m.getField(mapStage);
			monscount+=8;
			playerX = 4;
			playerY = 19;
			locate(0,0);
			return;
		}
		else if(playerX + x == 29 && playerY + y == 0 && mapStage == 1) {//map 1 to map 3
			temp ="";
			mapStage += 2;
			map = m.getField(mapStage);
			monscount+=8;
			playerX = 4;
			playerY = 19;
			locate(0,0);
			return;
		}
		else if(playerX + x == 4 && playerY + y == 20 && mapStage == 3) {//map 3 to map 1
			temp ="";
			mapStage -= 2;
			map = m.getField(mapStage);
			monscount-=8;
			playerX = 29;
			playerY = 1;
			locate(0,0);
			return;
		}
		else if(playerX + x == 5 && playerY + y == 20 && mapStage == 3) {//map 3 to map 1
			temp ="";
			mapStage -= 2;
			map = m.getField(mapStage);
			monscount-=8;
			playerX = 29;
			playerY = 1;
			locate(0,0);
			return;
		}
		else if(playerX + x == 6 && playerY + y == 0 && mapStage == 3) {//map 3 to map 4
			temp ="";
			mapStage++;
			map = m.getField(mapStage);
			monscount+=3;
			playerX = 34;
			playerY = 1;
			locate(0,0);
			return;
		}
		else if(playerX + x == 7 && playerY + y == 0 && mapStage == 3) {//map 3 to map 4
			temp ="";
			mapStage++;
			map = m.getField(mapStage);
			monscount+=3;
			playerX = 34;
			playerY = 1;
			locate(0,0);
			return;
		}
		else if(playerX + x == 4 && playerY + y == 20 && mapStage == 4) {//map 4 to map 3
			temp ="";
			mapStage--;
			map = m.getField(mapStage);
			monscount-=3;
			playerX = 7;
			playerY = 1;
			locate(0,0);
			return;
		}
		else if(playerX + x == 5 && playerY + y == 20 && mapStage == 4) {//map 4 to map 3
			temp ="";
			mapStage--;
			map = m.getField(mapStage);
			monscount-=3;
			playerX = 7;
			playerY = 1;
			locate(0,0);
			return;
		}
		else if(playerX + x == 37 && playerY + y == 0 && mapStage == 4) {//map 4 to map 5
			temp ="";
			mapStage++;
			map = m.getField(mapStage);
			monscount+=4;
			playerX = 36;
			playerY = 19;
			locate(0,0);
			return;
		}
		else if(playerX + x == 36 && playerY + y == 0 && mapStage == 4) {//map 4 to map 5
			temp ="";
			mapStage++;
			map = m.getField(mapStage);
			monscount+=4;
			playerX = 36;
			playerY = 19;
			locate(0,0);
			return;
		}
		else if(playerX + x == 35 && playerY + y == 20 && mapStage == 5) {//map 5 to map 4
			temp ="";
			mapStage--;
			map = m.getField(mapStage);
			monscount-=4;
			playerX = 36;
			playerY = 1;
			locate(0,0);
			return;
		}
		else if(playerX + x == 36 && playerY + y == 20 && mapStage == 5) {//map 5 to map 4
			temp ="";
			mapStage--;
			map = m.getField(mapStage);
			monscount-=4;
			playerX = 36;
			playerY = 1;
			locate(0,0);
			return;
		}
		else if(playerX + x == 3 && playerY + y == 0 && mapStage == 5) {//map 5 to map 6
			temp ="";
			mapStage++;
			map = m.getField(mapStage);
			monscount+=4;
			playerX = 19;
			playerY = 19;
			locate(0,0);
			return;
		}
		else if(playerX + x == 4 && playerY + y == 0 && mapStage == 5) {//map 5 to map 6
			temp ="";
			mapStage++;
			map = m.getField(mapStage);
			monscount+=4;
			playerX = 19;
			playerY = 19;
			locate(0,0);
			return;
		}
		else if(playerX + x == 19 && playerY + y == 20 && mapStage == 6) {//map 6 to map 5
			temp ="";
			mapStage--;
			map = m.getField(mapStage);
			monscount-=4;
			playerX = 4;
			playerY = 1;
			locate(0,0);
			return;
		}
		else if(playerX + x == 20 && playerY + y == 20 && mapStage == 6) {//map 6 to map 5
			temp ="";
			mapStage--;
			map = m.getField(mapStage);
			monscount-=4;
			playerX = 4;
			playerY = 1;
			locate(0,0);
			return;
		}
		
		//boundary
		if(playerX + x >= 40 || playerX + x < 0)return;
		if(playerY + y >= 20 || playerY + y < 0)return;
		
		
		//set
		if(temp.isEmpty() == false) {
			map.set(playerY, temp);
		}
		
		temp = map.get(playerY+y);
		
		
		char[] tempo = map.get(playerY + y).toCharArray();
		tempo[playerX + x] = '*';
		map.set(playerY + y, String.valueOf(tempo));
		playerY += y;
		playerX += x;
		
	}
	
	static void play() {
		int action=0;
		map = m.getField(mapStage);
		
		do {
			locate(0,0);
			printMap();
			
			try {
				System.out.print("What is your action? >> ");
				action = scan.nextInt();
				scan.nextLine();
			} catch (Exception e) {
				System.out.println("Must input with numbers");
				scan.nextLine();
			}
			
			switch(action){
			case 1:
				String Move = null;
				boolean check = true;
				do {
					System.out.print("Input your direction [A|S|D|W] : ");
					Move = scan.nextLine();
					
					if(Move.length() == 1) {
						if(Move.equals("W") == true ) {
							check = false;
							locate(0,-1);
						}
						else if(Move.equals("A") == true) {
							check = false;
							locate(-1,0);
						}
						else if(Move.equals("S") == true ) {
							check = false;
							locate(0,1);
						}
						else if(Move.equals("D") == true) {
							check = false;
							locate(1,0);
						}
					}
				} while (check);
				break;
			case 2:
				showStat();
				break;
			case 3:
				break;
			}
		
		} while (action!=4);
	}
	
	static void newGame() {
		String Name;
		String Type;
		playerX = 5;
		playerY = 19;
		System.out.println("Welcome to Short Adventure");
		do {
			System.out.print("What is your name??[1-25 Characters] >>");
			Name = scan.nextLine();
		} while (Name.length()<1 || Name.length()>25);
		do {
			System.out.print("What class do you prefer??[SwordsMan | BowMan | Mage](Case Sensitive) >> ");
			Type = scan.nextLine();
		} while (!(Type.equals("SwordsMan")) && !(Type.equals("BowMan")) && !(Type.equals("Mage")));
		
		if(Type.equals("SwordsMan")){
			Profile data = new Swordman(Name, 15, 7, 6,8, 20);
			temp1 = 15;
			attack1 = 7;
			defend1 = 6;
			speed1 = 8;
			special1 = 20;
			playerList.add(data);
		} else if (Type.equals("BowMan")){
			Profile data = new Bowman(Name, 12, 6, 4, 10, 30);
			temp1 = 12;
			attack1 = 6;
			defend1 = 4;
			speed1 = 10;
			special1 = 30;
			playerList.add(data);
		} else {
			Profile data = new Mage(Name, 11, 5, 2, 7, 40);
			temp1 = 11;
			attack1 = 5;
			defend1 = 2;
			speed1 = 7;
			special1 = 40;
			playerList.add(data);
		}
		System.out.println("Hello "+Name+" welcome to the world of Kultz a beautifull world full of magic and harmony");
		System.out.println("My name is Axel and i'm here to guide you");
		System.out.println("Long time ago, Kultz was a beautifull world full of beautiful creature and harmony.");
		System.out.println("The world was guarded and commanded by a kingdom called Naisunib whit a king called Haryto, who was wise and kind.");
		System.out.println("The king had a beautifull princess called Isabella, who was pretty and kind");
		System.out.println("Until one day, Axolt the king of destruction came and kidnaped the queen and destroy this world.");
		System.out.println("There was a prophecy that said there will be a brave knight, who will save the queen from the mad king and recover ...");
		System.out.println("Many years had passed and many knights have tried, but not every single of them have came back alive.");
		System.out.println("People started to gave up, but now this is your turn to tried and fullfil the prophecy.");
		System.out.println("Goodluck "+Name+" your adventure begin!!!");
		System.out.println("Press enter to continue...");
		scan.nextLine();
		play();
	}
	
	public static void main(String[] args) {
		int pilihan = 0;
		addMonster();
		
		do {
			pilihan = 0;
			Menu();
			try {
				pilihan = scan.nextInt();
				scan.nextLine();
			} catch (Exception e) {
				System.out.println("Must input with numbers!!!");
				scan.nextLine();
			}
			
			switch(pilihan){
			case 1:
				cls();
				newGame();
				break;
			case 2:
				cls();
				play();
				break;
			case 3:
				cls();
				Rules();
				break;
			case 4:
				cls();
				System.out.println("Thank you for playing Short Adventure!!!!");
				scan.nextLine();
				break;
			}
			
		} while (pilihan!=4);

	}

}
