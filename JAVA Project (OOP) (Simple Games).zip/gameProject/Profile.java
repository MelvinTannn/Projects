package gameProject;

public abstract class Profile {

	protected int health;
	protected int attack;
	protected int defend;
	protected int speed;
	protected String name;
	
	public abstract int getHealth();
	public abstract void setHealth(int health);
	
	public abstract int getAttack();
	public abstract void setAttack(int attack);
	
	public abstract int getDefend();
	public abstract void setDefend(int defend);
	
	public abstract int getSpeed();
	public abstract void setSpeed(int speed);
	
	public abstract String getName();
	public abstract void setName(String name);
	
	public abstract int getSpecial();
	public abstract void setSpecial(int special);
	
	public abstract void image();
	public abstract int luck();

}
