package gameProject;

public class Wizard extends Mage{

	public Wizard() {
		super("Wizard",45, 10, 20, 8, 50);
	}

	public void image() {
		System.out.println("        / \\");
		System.out.println("       /   \\     ");
		System.out.println("      /     \\");
		System.out.println("     (_______)  __");
		System.out.println("     /|_| |_|\\ (__)");
		System.out.println("     \\_______/ / /");
		System.out.println("  _  /\\     /\\/ /");
		System.out.println(" | |/  \\   /  \\/");
		System.out.println(" | |\\   \\_/   /");
		System.out.println(" |_| \\_______/");
		System.out.println("      (_) (_)");
	}
	
}
