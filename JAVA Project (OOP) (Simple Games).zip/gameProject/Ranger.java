package gameProject;

public class Ranger extends Bowman {

	public Ranger() {
		super("Ranger", 15, 25, 7, 30, 35);
	}
	
	public void image() {
		System.out.println("     /-----------\\        ");
		System.out.println("    /_____________\\       ");
		System.out.println("     ||_|   |_| |          ");
		System.out.println(" /-\\ |          |         ");
		System.out.println("  \\  \\__________/  ___   ");
		System.out.println("   \\ /          \\  \\_/  ");
		System.out.println("    /       _____|__|__    ");
		System.out.println("    |       \\    |  |  /  ");
		System.out.println("    |        \\___|__|_/   ");
		System.out.println("     \\__________/   |     ");
		System.out.println("     (_)      (_)  \\-/    ");
	}

}
