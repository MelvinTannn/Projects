package gameProject;

import java.util.Random;

public class Swordman extends Profile implements Special{

private int physical;
Random rand = new Random();
	
	public Swordman(String name, int health, int attack, int defend, int speed, int physical) {
		super();
		this.name = name;
		this.health = health;
		this.attack = attack;
		this.defend = defend;
		this.speed = speed;
		this.physical = physical;
		
	}

	public int getPhysical() {
		return physical;
	}

	public void setPhysical(int physical) {
		this.physical = physical;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public int getDefend() {
		return defend;
	}

	public void setDefend(int defend) {
		this.defend = defend;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSpecial(){
		return physical;
	}
	
	public void setSpecial(int physical){
		this.physical = physical;
	}
	
	public int hasil(){
		
		int aa=rand.nextInt(physical);
		return aa;
	}
	
	public int luck(){
		int bb = hasil();
		return bb;
	}
	public void image() {
		
	}

}
