package gameProject;

public class UndeadWarrior extends Swordman {

	public UndeadWarrior() {
		super("Undead Warrior", 20, 15, 8,6,7);
	}

	public void image() {
		System.out.println("      _______");
		System.out.println("     / _   _ \\         /\\");
		System.out.println("    / |_| |_| \\       / /");
		System.out.println("    \\    o    /      / /");
		System.out.println(" __  |_|_|_|_|      / /");
		System.out.println("/  \\_____|_____(_)_/ /_");
		System.out.println("|  |_____|_____ |_____/");
		System.out.println("|  |_____|_____ |/ /");
		System.out.println("\\__/    _|_     /_/");
		System.out.println("       |   |     ");
		System.out.println("      (_) (_)");
	}
	
}
