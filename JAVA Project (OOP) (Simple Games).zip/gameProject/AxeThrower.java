package gameProject;

public class AxeThrower extends Bowman{

	public AxeThrower() {
		super("Axe Thrower", 50, 15, 15, 25, 10);
	}

	public void image() {
		System.out.println("      ____                         ");
		System.out.println("     \\    /                       ");
		System.out.println("      |  |=====(=)===()            ");
		System.out.println("     /____\\    | |                ");
		System.out.println("               | |                 ");
		System.out.println("      _____    | |                 ");
		System.out.println("     / o   \\___| |__________      ");
		System.out.println("     | o     _______  ____  |      ");
		System.out.println("     \\_____/        //    //      ");
		System.out.println("                   //    //        ");
		System.out.println("                  (_)   (_)        ");
	}
}
