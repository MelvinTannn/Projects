package gameProject;

public class Mimic extends Mage{

	public Mimic() {
		super("Mimic", 50, 2, 10, 10, 30);
	}

	public void image() {
		System.out.println("     ________");
		System.out.println("    /        /\\");
		System.out.println("   /        / /_");
		System.out.println("  /        / / /|   /\\");
		System.out.println(" /________/ /_/ | _/ /");
		System.out.println("/  _______\\/_ \\ |/ _/");
		System.out.println("| /\\/\\/\\/\\/ /\\ \\/ /");
		System.out.println("|/_________/  \\__/");
		System.out.println("|          |   / ");
		System.out.println("|          |  /");
		System.out.println("|          | / ");
		System.out.println("|__________|/");
	}
}
