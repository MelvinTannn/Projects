package gameProject;

public class Ghoul extends Swordman {

	public Ghoul() {
		super("Ghoul", 30, 5, 3, 20, 10);
	}

	public void image() {
		System.out.println("      _______");
		System.out.println("     / _   _ \\");
		System.out.println("    / |_| |_| \\");
		System.out.println("    \\    o    /");
		System.out.println("  _  |_|_|_|_|  _");
		System.out.println(" (_)_____|_____(_)");
		System.out.println("  | _____|_____ |");
		System.out.println("  | _____|_____ |");
		System.out.println("  |     _|_     |");
		System.out.println(" /|\\   |   |   /|\\");
		System.out.println("      /|\\ /|\\");
	}
}
